#include<Windows.h>

LRESULT CALLBACK WndProc(HWND hwnd,UINT message,WPARAM wParam,LPARAM lParam);
// WinMain is the entry point function of the Windows application.
// _stdcall is the calling convention used in Win32 API
// The second parameter of entry point function is always set to NULL in Win 32
// The second parameter of entry point function is set to NULL/previous instance handle in Win 16
int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nShowCmd)
{
    char szAppName[] = "MainWnd";
    WNDCLASSA wndclass;
    wndclass.style=(CS_HREDRAW | CS_VREDRAW);
    wndclass.lpfnWndProc = WndProc;
    wndclass.cbClsExtra=0;
    wndclass.cbWndExtra=0;
    wndclass.hInstance=hInstance;
    wndclass.hIcon=LoadIcon(NULL,IDI_APPLICATION);
    wndclass.hCursor=LoadCursor(NULL,IDC_ARROW);
    //wndclass.hbrBackground = CreateSolidBrush(RGB(0, 0, 255));
    wndclass.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);
    wndclass.lpszMenuName=NULL;
    wndclass.lpszClassName=szAppName;

    
        // Title bars are optional for popup windows


    if (!RegisterClassA(&wndclass))
    {
        MessageBoxA(NULL,"This program requires windows NT!",szAppName,MB_ICONERROR);
        return 0;
    }
   

    HWND hwnd=CreateWindowExA(0,szAppName,"Notepad",WS_OVERLAPPEDWINDOW,
    CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,
    NULL,NULL,hInstance,NULL);

   

    ShowWindow(hwnd,nShowCmd);
    

    UpdateWindow(hwnd);

    MSG msg;

    // GetMessage returns 0 when it retrieves WM_QUIT message from application message queue
    // All Input (keyboard, mouse) messages are high priority messages
    // Except WM_PAINT all messages are removed from application message queue by GetMessage
    // PeekMessage such as PeekMessage(&msg, 0, 0, 0) retrieves both windows and thread messages
    while(GetMessageA(&msg,NULL,0,0))
    {
        TranslateMessage(&msg);
        DispatchMessageA(&msg);
    }
    return msg.wParam;
}


// The size of WPARAM in Win16 is 16 bit

// The size of WPARAM in Win32 is 32 bit

// The size of LPARAM is always 32 bit




LRESULT CALLBACK WndProc(HWND hwnd,UINT message,WPARAM wParam,LPARAM lParam)
{
    switch(message)
    {
        case WM_CLOSE:
            DestroyWindow(hwnd);
            OutputDebugStringA("WN_CLOSE");
            break;
        case WM_DESTROY:
            PostQuitMessage(100);
            OutputDebugStringA("WN_DESTROY");
            break;
        default:
            return DefWindowProcA(hwnd,message,wParam,lParam);
    }
    return 0;
}



/*

- Use Settings > Accessiblity > Contrast Theme to change color schemes

- What does class abstracts?

- Can a Windows application have several WNDCLASS instances?

*/