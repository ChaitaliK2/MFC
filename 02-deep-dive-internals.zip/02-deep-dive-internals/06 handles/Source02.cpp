/***** API Developer's Code *******/
struct Dummy {
	int i;
};

int index = -1;

const size_t size = 16;
void* pobjects[size];


void F(int handle) {
	static_cast<Dummy*>(pobjects[handle])->i = 5;
}

int CreateDummy() {
	Dummy* pdummy = new Dummy();
	pobjects[++index] = pdummy;
	return index;
}

void Release(int handle) {
	delete static_cast<Dummy*>(pobjects[handle]);
}

/* Application Developer's Code *****/
int main() {
	int hDummy = CreateDummy();

	F(hDummy); // this is ok

	Release(hDummy);
}