/***** API Developer's Code *******/
struct Dummy {
	int i;
};

void F(Dummy* pdummy) {
	pdummy->i = 5;
}

Dummy* CreateDummy() {
	Dummy* pdummy = new Dummy();
	return pdummy;
}

void Release(Dummy* pdummy) {
	delete pdummy;
}

/* Application Developer's Code *****/
int main() {
	Dummy* pmydummy = CreateDummy();

	F(pmydummy); // this is ok
	
	pmydummy->i = -5; // this is dangerous

	Release(pmydummy);
}

/*
- In above code, CreateDummy API is sharing address of the dynamically allocated object
  with application developer.
- This could be dangerous as now application developer has direct access to
  the state of the object.
- Application developer may alter the state of the object to such a state
  which may not be suitable for that object.
- Hence this has to be prohibited.
*/