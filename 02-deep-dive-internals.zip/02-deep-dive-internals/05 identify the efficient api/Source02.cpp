/***** API Developer's Code *******/
#include <cstdio>
#include <Windows.h>

void PrintA(const char* s);
void PrintW(const wchar_t* ws);

void PrintA(const char* s) {
	printf("%s", s);
}

void PrintW(const wchar_t* ws) {
	size_t size = wcslen(ws);
	char* ps = new char[size + 1];
	WideCharToMultiByte(CP_UTF8, 0, ws, size + 1, ps, size + 1, NULL, NULL);
	PrintA(ps);
	delete[] ps;
	ps = nullptr;
}

/* Application Developer's Code *****/
int main() {
	PrintA("Hello, World\n");
	PrintW(L"Hello, World\n");
}

/*
- Which call out of PrintA or PrintW is most efficient?
*/