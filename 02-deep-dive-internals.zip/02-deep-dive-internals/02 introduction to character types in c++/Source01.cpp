int main() {
	char ch = 'A'; // narrow character
	char s[] = "Hello, World"; // narrow character string

	wchar_t wch = L'A'; // wide character
	wchar_t ws[] = L"Hello, World"; // wide character string
}